"""
indicators.py - green LED, red LED and buzzer.

Patterns run in a small background thread so the NFC loop and MQTT callbacks
are never blocked while the LED / buzzer are busy.

  ok()    -> green LED (1 s) + one short beep
  error() -> red LED  (~0.7 s) + two short beeps
"""
import logging
import threading
import time

import board
import digitalio

import config

log = logging.getLogger("indicators")


def _make_output(bcm_pin, initial):
    io = digitalio.DigitalInOut(getattr(board, f"D{bcm_pin}"))
    io.switch_to_output(value=initial)
    return io


class Indicators:
    def __init__(self):
        self._lock = threading.Lock()
        off = not config.BUZZER_ACTIVE_HIGH
        self._green = _make_output(config.GREEN_LED_PIN, False)
        self._red = _make_output(config.RED_LED_PIN, False)
        self._buzzer = _make_output(config.BUZZER_PIN, off)

    # ---- low level
    def _beep(self, seconds):
        self._buzzer.value = config.BUZZER_ACTIVE_HIGH
        time.sleep(seconds)
        self._buzzer.value = not config.BUZZER_ACTIVE_HIGH

    def _ok_pattern(self):
        self._green.value = True
        self._beep(0.15)
        time.sleep(0.85)
        self._green.value = False

    def _error_pattern(self):
        self._red.value = True
        self._beep(0.1)
        time.sleep(0.1)
        self._beep(0.1)
        time.sleep(0.4)
        self._red.value = False

    def _run(self, pattern):
        def worker():
            with self._lock:          # patterns never overlap
                pattern()
        threading.Thread(target=worker, daemon=True).start()

    # ---- public
    def ok(self):
        self._run(self._ok_pattern)

    def error(self):
        self._run(self._error_pattern)

    def close(self):
        with self._lock:
            self._green.value = False
            self._red.value = False
            self._buzzer.value = not config.BUZZER_ACTIVE_HIGH
            for io in (self._green, self._red, self._buzzer):
                io.deinit()
