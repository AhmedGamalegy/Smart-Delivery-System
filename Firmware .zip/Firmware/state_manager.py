"""
state_manager.py - the BRAIN of the project (Raspberry Pi decides).

Owns:  state machine, card validation, geofence, delivery validation,
       issue recording, duplicate protection, persistence (shipment_state.json).

Node-RED never decides anything - it only shows what this file publishes.

State machine (forward only):
  READY_FOR_PICKUP -> PICKED_UP -> IN_TRANSIT -> NEAR_DESTINATION
                   -> CUSTOMER_VERIFIED -> DELIVERED
There is NO automatic failure state.
"""
import json
import logging
import os
import threading
from datetime import datetime
from math import asin, cos, radians, sin, sqrt

import config
from config import normalize_uid

log = logging.getLogger("state")

# ---- states
READY_FOR_PICKUP = "READY_FOR_PICKUP"
PICKED_UP = "PICKED_UP"
IN_TRANSIT = "IN_TRANSIT"
NEAR_DESTINATION = "NEAR_DESTINATION"
CUSTOMER_VERIFIED = "CUSTOMER_VERIFIED"
DELIVERED = "DELIVERED"

ISSUE_TYPES = (
    "العميل غير متاح",
    "مشكلة في المركبة",
    "مشكلة في الشحنة",
    "تأخير غير مخطط",
)
ISSUE_DOUBLE_CLICK_SECONDS = 10       # same type+details again within this time = duplicate
MAX_ISSUES_KEPT = 50
MAX_DETAILS_LENGTH = 500


def now_iso():
    """Local time with UTC offset, e.g. 2026-09-24T15:04:05+03:00"""
    return datetime.now().astimezone().isoformat(timespec="seconds")


def distance_meters(lat1, lon1, lat2, lon2):
    """Haversine distance between two GPS points, in meters."""
    r = 6371000.0
    p1, p2 = radians(lat1), radians(lat2)
    dphi, dlmb = radians(lat2 - lat1), radians(lon2 - lon1)
    a = sin(dphi / 2) ** 2 + cos(p1) * cos(p2) * sin(dlmb / 2) ** 2
    return 2 * r * asin(sqrt(a))


def _default_state():
    return {
        "shipmentId": config.SHIPMENT_ID,
        "status": READY_FOR_PICKUP,
        "courierCardVerified": False,
        "customerCardVerified": False,
        "readyNotificationSent": False,
        "lastKnownLocation": None,          # {"latitude": .., "longitude": ..}
        "lastLocationTimestamp": None,
        "deliveryConfirmed": False,
        "deliveredTimestamp": None,
        "issues": [],
        "events": [],
    }


class ShipmentManager:
    def __init__(self, publish):
        """publish(topic, payload_dict, retain=False) is provided by mqtt_client."""
        self._publish = publish
        self.lock = threading.RLock()       # MQTT thread and NFC loop both call us
        self.courier_uid = normalize_uid(config.COURIER_CARD_UID)
        self.customer_uid = normalize_uid(config.CUSTOMER_CARD_UID)
        self.data = self._load()

    # ------------------------------------------------------------ persistence
    def _load(self):
        path = config.STATE_FILE
        if path.exists():
            try:
                with open(path, encoding="utf-8") as f:
                    saved = json.load(f)
                if saved.get("shipmentId") == config.SHIPMENT_ID:
                    state = _default_state()
                    state.update(saved)
                    log.info("Loaded saved state: %s", state["status"])
                    return state
                log.warning("Saved state is for shipment %s - starting fresh", saved.get("shipmentId"))
            except (OSError, ValueError, AttributeError) as err:
                log.warning("Could not read %s (%s) - starting fresh", path.name, err)
                try:
                    path.replace(path.with_name(path.name + ".bad"))
                except OSError:
                    pass
        log.info("No saved state - new shipment starts in %s", READY_FOR_PICKUP)
        return _default_state()

    def _save(self):
        tmp = config.STATE_FILE.with_name(config.STATE_FILE.name + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, config.STATE_FILE)   # atomic: the file is never half-written

    # ------------------------------------------------------------ publishing
    def _publish_state(self):
        s = self.data
        self._publish(
            config.TOPIC_STATE,
            {
                "shipment_id": s["shipmentId"],
                "state": s["status"],
                "customer_verified": s["customerCardVerified"],
                "timestamp": now_iso(),
            },
            retain=True,
        )

    def _publish_location(self):
        loc = self.data["lastKnownLocation"]
        if not loc:
            return
        self._publish(
            config.TOPIC_LOCATION,
            {
                "shipment_id": self.data["shipmentId"],
                "latitude": loc["latitude"],
                "longitude": loc["longitude"],
                "timestamp": self.data["lastLocationTimestamp"],
            },
            retain=True,
        )

    def _record_event(self, name, **extra):
        """Add to the events list, save the file, publish. Caller holds the lock."""
        event = {"event": name, "shipment_id": self.data["shipmentId"], "timestamp": now_iso(), **extra}
        self.data["events"].append(event)
        del self.data["events"][:-config.MAX_EVENTS_KEPT]
        self._save()
        self._publish(config.TOPIC_EVENTS, event, retain=False)
        log.info("EVENT %s %s", name, extra if extra else "")

    def _transition(self, new_status, event_name, **extra):
        old = self.data["status"]
        self.data["status"] = new_status
        self._record_event(event_name, **extra)   # this also saves the new status
        self._publish_state()
        log.info("STATE %s -> %s", old, new_status)

    def republish(self):
        """Called every time MQTT (re)connects, so Node-RED always has the latest picture."""
        with self.lock:
            self._publish_state()
            self._publish_location()

    # ------------------------------------------------------------ NFC cards
    def handle_card(self, uid):
        """uid is already normalized. Returns True if accepted, False if rejected."""
        with self.lock:
            s = self.data

            if uid == self.courier_uid and s["status"] == READY_FOR_PICKUP:
                s["courierCardVerified"] = True
                self._transition(PICKED_UP, "picked_up")
                return True

            if uid == self.customer_uid and s["status"] == NEAR_DESTINATION:
                s["customerCardVerified"] = True
                self._transition(CUSTOMER_VERIFIED, "customer_verified")
                return True

            if uid == self.courier_uid:
                card, reason = "courier", "wrong_state"
            elif uid == self.customer_uid:
                card, reason = "customer", "wrong_state"
            else:
                card, reason = "unknown", "unknown_card"
            self._record_event("nfc_rejected", card=card, reason=reason)
            return False

    # ------------------------------------------------------------ OwnTracks location
    def _is_old_fix(self, timestamp):
        last = self.data["lastLocationTimestamp"]
        if not last:
            return False
        try:
            return datetime.fromisoformat(timestamp) <= datetime.fromisoformat(last)
        except ValueError:
            return False

    def handle_location(self, lat, lon, timestamp):
        """timestamp = time of the GPS fix (ISO text). Geofence lives HERE, not in Node-RED."""
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            log.warning("Ignoring invalid coordinates: %s, %s", lat, lon)
            return
        with self.lock:
            s = self.data
            # OwnTracks messages are retained, so after every MQTT reconnect the last
            # one arrives again. Same-or-older fixes are duplicates: ignore them.
            if self._is_old_fix(timestamp):
                return

            s["lastKnownLocation"] = {"latitude": lat, "longitude": lon}
            s["lastLocationTimestamp"] = timestamp
            self._save()
            self._publish_location()

            if s["status"] == PICKED_UP:
                self._transition(IN_TRANSIT, "in_transit")

            if s["status"] == IN_TRANSIT and not s["readyNotificationSent"]:
                dist = distance_meters(lat, lon, config.DESTINATION_LAT, config.DESTINATION_LON)
                log.info("Distance to destination: %.0f m (radius %d m)", dist, config.DESTINATION_RADIUS_METERS)
                if dist <= config.DESTINATION_RADIUS_METERS:
                    s["readyNotificationSent"] = True          # duplicate protection: ONCE only
                    self._transition(NEAR_DESTINATION, "ready_for_pickup")

    # ------------------------------------------------------------ commands from Node-RED
    def handle_command(self, cmd):
        if not isinstance(cmd, dict):
            return
        if cmd.get("shipment_id") != config.SHIPMENT_ID:
            log.warning("Ignoring command for another shipment: %s", cmd.get("shipment_id"))
            return
        name = cmd.get("command")
        with self.lock:
            if name == "confirm_delivery":
                self._confirm_delivery()
            elif name == "issue_report":
                self._issue_report(cmd)
            else:
                log.warning("Unknown command: %s", name)

    def _confirm_delivery(self):
        s = self.data
        if s["deliveryConfirmed"] or s["status"] == DELIVERED:
            log.info("confirm_delivery ignored: already delivered (idempotent)")
            return                                       # no 2nd event, no 2nd email
        if not s["customerCardVerified"]:
            self._record_event("confirm_delivery_rejected", reason="customer_not_verified")
            return
        if s["status"] != CUSTOMER_VERIFIED:
            self._record_event("confirm_delivery_rejected", reason="wrong_state")
            return
        s["deliveryConfirmed"] = True
        s["deliveredTimestamp"] = now_iso()
        self._transition(DELIVERED, "delivered")

    def _issue_report(self, cmd):
        s = self.data
        issue_type = cmd.get("issue_type")
        details = str(cmd.get("details") or "")[:MAX_DETAILS_LENGTH]
        cmd_time = str(cmd.get("timestamp") or "")

        if issue_type not in ISSUE_TYPES:
            self._record_event("issue_rejected", reason="invalid_issue_type")
            return

        # duplicate protection: same MQTT message twice, or a quick double click
        for old in s["issues"][-10:]:
            if old["issue_type"] != issue_type or old["details"] != details:
                continue
            if cmd_time and old.get("command_timestamp") == cmd_time:
                log.info("issue_report ignored: duplicate command")
                return
            age = (datetime.now().astimezone() - datetime.fromisoformat(old["reported_at"])).total_seconds()
            if age < ISSUE_DOUBLE_CLICK_SECONDS:
                log.info("issue_report ignored: repeated within %d s", ISSUE_DOUBLE_CLICK_SECONDS)
                return

        loc = s["lastKnownLocation"] or {}
        issue = {
            "issue_type": issue_type,
            "details": details,
            "reported_at": now_iso(),
            "command_timestamp": cmd_time,
            "latitude": loc.get("latitude"),
            "longitude": loc.get("longitude"),
            "last_location_timestamp": s["lastLocationTimestamp"],
        }
        s["issues"].append(issue)
        del s["issues"][:-MAX_ISSUES_KEPT]
        # NOTE: the shipment state is NOT changed - an issue never means "failed".
        self._record_event(
            "issue_reported",
            issue_type=issue_type,
            details=details,
            latitude=issue["latitude"],
            longitude=issue["longitude"],
            last_location_timestamp=issue["last_location_timestamp"],
        )
