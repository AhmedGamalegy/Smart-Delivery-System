"""
main.py - Smart Delivery Tracking (Raspberry Pi = brain).

Run:            python main.py
Fresh start:    python main.py --reset      (deletes shipment_state.json first - for testing)
Stop:           Ctrl+C
"""
import logging
import sys
import time
from datetime import datetime

import config
from indicators import Indicators
from mqtt_client import MqttClient
from nfc_reader import NfcReader
from state_manager import ShipmentManager

log = logging.getLogger("main")


def check_config():
    problems = []
    if not config.MQTT_HOST:
        problems.append("MQTT_HOST is empty - fill in the .env file")
    if not config.MQTT_USERNAME or not config.MQTT_PASSWORD:
        problems.append("MQTT_USERNAME / MQTT_PASSWORD are empty - fill in the .env file")
    if config.COURIER_CARD_UID.startswith("PUT_") or config.CUSTOMER_CARD_UID.startswith("PUT_"):
        problems.append("Set COURIER_CARD_UID and CUSTOMER_CARD_UID in config.py (run pn532_test.py to read them)")
    elif config.normalize_uid(config.COURIER_CARD_UID) == config.normalize_uid(config.CUSTOMER_CARD_UID):
        problems.append("COURIER_CARD_UID and CUSTOMER_CARD_UID must be two different cards")
    if problems:
        print("\nCannot start:")
        for p in problems:
            print("  -", p)
        sys.exit(1)


def owntracks_to_manager(manager):
    """Turn an OwnTracks JSON message into a call to the state manager."""
    def handler(data):
        if not isinstance(data, dict) or data.get("_type") != "location":
            return
        try:
            lat, lon = float(data["lat"]), float(data["lon"])
        except (KeyError, TypeError, ValueError):
            return
        try:                                            # "tst" = time of the GPS fix (epoch seconds)
            fix_time = datetime.fromtimestamp(int(data["tst"]))
        except (KeyError, TypeError, ValueError, OSError):
            fix_time = datetime.now()
        manager.handle_location(lat, lon, fix_time.astimezone().isoformat(timespec="seconds"))
    return handler


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)-7s %(name)s: %(message)s", datefmt="%H:%M:%S")
    check_config()

    if "--reset" in sys.argv and config.STATE_FILE.exists():
        config.STATE_FILE.unlink()
        log.info("Old %s deleted (--reset)", config.STATE_FILE.name)

    indicators = Indicators()
    try:
        nfc = NfcReader()
    except Exception as err:
        indicators.close()
        print(f"\nCannot start the PN532: {err}")
        print("Check the wiring and run  i2cdetect -y 1  (you should see 24), then try pn532_test.py")
        sys.exit(1)

    mqtt = MqttClient()
    manager = ShipmentManager(mqtt.publish)              # loads shipment_state.json
    mqtt.on_command = manager.handle_command
    mqtt.on_owntracks = owntracks_to_manager(manager)
    mqtt.on_connected = manager.republish
    mqtt.start()

    log.info("Running - shipment %s is %s. Waiting for cards...", config.SHIPMENT_ID, manager.data["status"])

    last_uid, last_seen = None, 0.0
    try:
        while True:
            uid = nfc.read_uid(timeout=0.5)
            if uid is None:
                continue
            now = time.monotonic()
            repeated = uid == last_uid and now - last_seen < config.NFC_REPEAT_SECONDS
            last_uid, last_seen = uid, now
            if repeated:                                 # card is still sitting on the reader
                continue
            log.info("Card scanned: %s", uid)
            if manager.handle_card(uid):
                indicators.ok()
            else:
                indicators.error()
    except KeyboardInterrupt:
        print("\nStopping...")
    finally:
        mqtt.stop()
        indicators.close()


if __name__ == "__main__":
    main()
