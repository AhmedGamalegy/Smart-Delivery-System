"""
config.py - all settings for the Smart Delivery project (Raspberry Pi side).

* Normal settings are edited here.
* Secrets (MQTT host / username / password) live in the .env file, NOT here,
  so this file is safe to put on GitHub.
"""
import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def normalize_uid(value):
    """Return a card UID as UPPER-CASE hex without separators.
    b'\\x04\\xa1' / '04:a1' / '04 A1' / '04-a1'  ->  '04A1'
    Used for BOTH the config values below and the UID read from the reader,
    so they always compare in the same format."""
    if isinstance(value, (bytes, bytearray)):
        return value.hex().upper()
    return "".join(ch for ch in str(value).upper() if ch in "0123456789ABCDEF")


# ---------------------------------------------------------------- Shipment
SHIPMENT_ID = "SH001"                 # must be the same as SHIPMENT_ID in Node-RED

# ---------------------------------------------------------------- NFC cards
# Run pn532_test.py, tap each card, and paste the UID it prints.
COURIER_CARD_UID = "PUT_COURIER_UID_HERE"
CUSTOMER_CARD_UID = "PUT_CUSTOMER_UID_HERE"
NFC_REPEAT_SECONDS = 3.0              # same card seen again within this time = ignored

# ---------------------------------------------------------------- Geofence
# CHANGE these to your real destination (example values = Tahrir Square, Cairo)
DESTINATION_LAT = 30.0444
DESTINATION_LON = 31.2357
DESTINATION_RADIUS_METERS = 100

# ---------------------------------------------------------------- GPIO (BCM numbers)
GREEN_LED_PIN = 17                    # physical pin 11
RED_LED_PIN = 27                      # physical pin 13
BUZZER_PIN = 22                       # physical pin 15
BUZZER_ACTIVE_HIGH = True             # True = buzzer beeps when the pin is HIGH

# ---------------------------------------------------------------- MQTT (HiveMQ Cloud)
MQTT_HOST = os.getenv("MQTT_HOST", "").strip()
MQTT_PORT = int(os.getenv("MQTT_PORT", "8883"))
MQTT_USERNAME = os.getenv("MQTT_USERNAME", "").strip()
MQTT_PASSWORD = os.getenv("MQTT_PASSWORD", "")
MQTT_CLIENT_ID = os.getenv("MQTT_CLIENT_ID", "smart-delivery-pi")

# OwnTracks publishes to  owntracks/<user>/<device>
OWNTRACKS_TOPIC = os.getenv("OWNTRACKS_TOPIC", "owntracks/+/+")

TOPIC_EVENTS = f"delivery/{SHIPMENT_ID}/events"
TOPIC_STATE = f"delivery/{SHIPMENT_ID}/state"
TOPIC_LOCATION = f"delivery/{SHIPMENT_ID}/location"
TOPIC_COMMANDS = f"delivery/{SHIPMENT_ID}/commands"

# ---------------------------------------------------------------- Persistence
STATE_FILE = BASE_DIR / "shipment_state.json"
MAX_EVENTS_KEPT = 100                 # older events are dropped from the JSON file
