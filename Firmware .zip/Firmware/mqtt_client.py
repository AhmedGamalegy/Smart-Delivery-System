"""
mqtt_client.py - connection to HiveMQ Cloud (TLS, port 8883).

* Reconnects automatically. A lost connection is NEVER treated as a failure of
  the shipment - the Pi just keeps working and reconnects in the background.
* Subscribes to:  the command topic (from Node-RED) and the OwnTracks topic.
* Handlers are plugged in by main.py:  on_command / on_owntracks / on_connected
"""
import json
import logging
import traceback

import paho.mqtt.client as mqtt

import config

log = logging.getLogger("mqtt")


class MqttClient:
    def __init__(self):
        self.on_command = lambda data: None
        self.on_owntracks = lambda data: None
        self.on_connected = lambda: None

        self._client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=config.MQTT_CLIENT_ID)
        self._client.username_pw_set(config.MQTT_USERNAME, config.MQTT_PASSWORD)
        self._client.tls_set()                                   # uses the system CA certificates
        self._client.reconnect_delay_set(min_delay=1, max_delay=30)
        self._client.on_connect = self._on_connect
        self._client.on_disconnect = self._on_disconnect
        self._client.on_message = self._on_message

    # ---- public
    def start(self):
        self._client.connect_async(config.MQTT_HOST, config.MQTT_PORT, keepalive=60)
        self._client.loop_start()                                # background thread

    def stop(self):
        self._client.loop_stop()
        self._client.disconnect()

    def publish(self, topic, payload, retain=False):
        """payload is a dict. QoS 1 so messages survive a short disconnect."""
        self._client.publish(topic, json.dumps(payload, ensure_ascii=False), qos=1, retain=retain)

    # ---- callbacks (paho v2 signatures)
    def _on_connect(self, client, userdata, flags, reason_code, properties):
        if reason_code.is_failure:
            log.error("MQTT connection refused: %s (check .env credentials)", reason_code)
            return
        log.info("MQTT connected to %s", config.MQTT_HOST)
        client.subscribe([(config.TOPIC_COMMANDS, 1), (config.OWNTRACKS_TOPIC, 1)])
        try:
            self.on_connected()
        except Exception:
            log.error("on_connected failed:\n%s", traceback.format_exc())

    def _on_disconnect(self, client, userdata, disconnect_flags, reason_code, properties):
        log.warning("MQTT disconnected (%s) - will retry automatically", reason_code)

    def _on_message(self, client, userdata, msg):
        try:
            data = json.loads(msg.payload.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            log.warning("Ignoring non-JSON message on %s", msg.topic)
            return
        try:
            if msg.topic == config.TOPIC_COMMANDS:
                self.on_command(data)
            elif mqtt.topic_matches_sub(config.OWNTRACKS_TOPIC, msg.topic):
                self.on_owntracks(data)
        except Exception:                                        # never let the MQTT thread die
            log.error("Error while handling %s:\n%s", msg.topic, traceback.format_exc())
