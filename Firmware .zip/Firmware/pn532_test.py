"""
pn532_test.py - ONLY tests the PN532 (I2C).

1. initialize PN532   2. wait for a card   3. read UID   4. print UID
(no MQTT, no Telegram, no shipment logic, no Dashboard)

Run:   python pn532_test.py        (stop with Ctrl+C)
"""
import time

import board
import busio
from adafruit_pn532.i2c import PN532_I2C

i2c = busio.I2C(board.SCL, board.SDA)
pn532 = PN532_I2C(i2c, debug=False)

ic, ver, rev, support = pn532.firmware_version
print(f"Found PN532 - firmware {ver}.{rev}")
pn532.SAM_configuration()

print("Waiting for a card... (Ctrl+C to stop)")
last_uid = None
last_seen = 0.0

try:
    while True:
        try:
            uid = pn532.read_passive_target(timeout=0.5)
        except RuntimeError as err:
            print("read error, retrying:", err)
            time.sleep(0.5)
            continue

        if uid is None:
            continue

        uid_hex = uid.hex().upper()
        now = time.monotonic()
        # print again only for a new card, or after the card was removed for >1 s
        if uid_hex != last_uid or now - last_seen > 1.0:
            spaced = " ".join(f"{b:02X}" for b in uid)
            print(f"UID: {uid_hex}    ({spaced})")
        last_uid, last_seen = uid_hex, now
except KeyboardInterrupt:
    print("\nStopped.")
