"""
nfc_reader.py - PN532 over I2C.

read_uid() returns the card UID as normalized hex text (e.g. "04A1B2C3"),
or None when there is no card. It never raises: I2C hiccups are logged and
the caller simply tries again.
"""
import logging
import time

import board
import busio
from adafruit_pn532.i2c import PN532_I2C

from config import normalize_uid

log = logging.getLogger("nfc")


class NfcReader:
    def __init__(self):
        i2c = busio.I2C(board.SCL, board.SDA)
        self._pn532 = PN532_I2C(i2c, debug=False)     # raises if the PN532 is not found
        self._pn532.SAM_configuration()
        self._error_streak = 0
        _, ver, rev, _ = self._pn532.firmware_version
        log.info("PN532 ready (firmware %d.%d)", ver, rev)

    def read_uid(self, timeout=0.5):
        try:
            uid = self._pn532.read_passive_target(timeout=timeout)
            self._error_streak = 0
        except (RuntimeError, OSError) as err:
            self._error_streak += 1
            if self._error_streak in (1, 20, 100):
                log.warning("PN532 read error (#%d): %s", self._error_streak, err)
            if self._error_streak % 10 == 0:
                try:                                   # try to wake the chip up again
                    self._pn532.SAM_configuration()
                except (RuntimeError, OSError):
                    pass
            time.sleep(0.2)
            return None
        return normalize_uid(uid) if uid else None
